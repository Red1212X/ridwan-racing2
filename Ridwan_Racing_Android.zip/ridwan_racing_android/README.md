# Ridwan Racing — Android APK project (v0.1)

This is a small native Android wrapper around the free Ridwan Racing browser prototype. It opens the game locally in a full-screen WebView; it does not require internet access or any permissions.

## Easiest free route: build APK in Android Studio
1. Install Android Studio from https://developer.android.com/studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose **Open** and select the extracted `ridwan_racing_android` folder.
4. Let Gradle sync. If prompted, install Android SDK Platform 35 and use JDK 17.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
6. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
7. Transfer that APK to your Android phone and install it. You may need to allow installs from your file manager for this file.

## Build APK for free in the cloud (without installing Android Studio)
This project includes `.github/workflows/build-apk.yml`.
1. Create a GitHub account if needed, then create a new repository.
2. Upload/extract these project files into the repository and commit them to the `main` branch.
3. Open the repository's **Actions** tab and run **Build Ridwan Racing APK** (or wait for the push build to finish).
4. Open the completed workflow run and download the `ridwan-racing-debug-apk` artifact. Extract it to get `app-debug.apk`.

The cloud route uses GitHub Actions' free allowance, subject to account limits and policy. It is not a signed Play Store release; it is a debug APK for personal testing.

## Current features and limits
- Android launcher app named **Ridwan Racing**.
- Splash title displays **Created by Ridwan**.
- Cars: RIDWAN (red), ALIF (blue), SAZIM (black).
- Local same-device racing prototype.
- No permissions, account, ads, or paid service needed.
- **Not online multiplayer yet.** Separate-phone multiplayer needs a networking layer and server/relay, which is a separate next step.
