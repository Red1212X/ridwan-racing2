# Ridwan Racing (Android prototype)

A landscape Android app wrapping a touch-controlled 3D driving prototype.

## Features
- Three.js 3D scene with a road, scenery, player car and traffic cars
- Touch steering, gas, brake and nitro
- Speed and distance HUD
- Android WebView wrapper

## Important
The current 3D renderer loads Three.js from jsDelivr at runtime, so the first launch needs an internet connection. This is a playable prototype, not yet a polished commercial-grade simulator.

## Build
The repository workflow can build this project on GitHub Actions and publish the debug APK as a workflow artifact.
